package com.mycompany.chatapppart1;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * MessageTest — Unit tests for the Message class.
 *
 * Test data from POE:
 *   Message 1: recipient=+27718693002, message="Hi Mike, can you join us for dinner tonight?", SendMessage=Send
 *   Message 2: recipient=08575975889,  message="Hi Keegan, did you receive the payment?",     SendMessage=Discard
 */
public class MessageTest {

    private Message message1;
    private Message message2;

    @BeforeEach
    public void setUp() {
        // Test Case 1 — valid recipient with international code
        message1 = new Message(1, "+27718693002",
                "Hi Mike, can you join us for dinner tonight?");

        // Test Case 2 — invalid recipient (no international code)
        message2 = new Message(2, "08575975889",
                "Hi Keegan, did you receive the payment?");
    }

    // -------------------------------------------------------
    // MESSAGE LENGTH TESTS
    // -------------------------------------------------------

    @Test
    public void testMessageLengthSuccess() {
        // Message 1 is well under 250 chars — should be ready to send
        assertEquals("Message ready to send.", message1.checkMessageLength());
    }

    @Test
    public void testMessageLengthFailure() {
        // Build a message that is exactly 260 characters (10 over limit)
        String longText = "A".repeat(260);
        Message longMsg = new Message(3, "+27718693002", longText);
        String result = longMsg.checkMessageLength();
        assertTrue(result.contains("exceeds 250 characters by 10"),
                "Should report exactly 10 characters over limit");
    }

    // -------------------------------------------------------
    // RECIPIENT CELL NUMBER TESTS
    // -------------------------------------------------------

    @Test
    public void testCheckRecipientCellSuccess() {
        // +271234567 — starts with + and is 10 chars — valid
        Message validMsg = new Message(1, "+271234567", "Test message hi");
        assertEquals("Cell phone number successfully captured.",
                validMsg.checkRecipientCell());
    }

    @Test
    public void testCheckRecipientCellFailureNoInternationalCode() {
        // 08575975889 — no + prefix — should fail
        assertEquals(
            "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.",
            message2.checkRecipientCell()
        );
    }

    @Test
    public void testCheckRecipientCellFailureTooLong() {
        // +27718693002 — 12 chars — exceeds 10 char limit
        String result = message1.checkRecipientCell();
        assertEquals(
            "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.",
            result
        );
    }

    // -------------------------------------------------------
    // MESSAGE HASH TESTS
    // -------------------------------------------------------

    @Test
    public void testMessageHashNotNull() {
        assertNotNull(message1.createMessageHash());
    }

    @Test
    public void testMessageHashIsAllCaps() {
        String hash = message1.createMessageHash();
        assertEquals(hash.toUpperCase(), hash,
                "Hash must be entirely uppercase");
    }

    @Test
    public void testMessageHashHasThreeParts() {
        String hash = message1.createMessageHash();
        String[] parts = hash.split(":");
        assertEquals(3, parts.length,
                "Hash must have exactly 3 colon-separated parts");
    }

    @Test
    public void testMessageHashFirstPartIsTwoDigits() {
        String hash = message1.createMessageHash();
        String firstPart = hash.split(":")[0];
        assertEquals(2, firstPart.length(),
                "First part of hash must be 2 characters (first 2 digits of message ID)");
    }

    @Test
    public void testMessageHashSecondPartIsMessageNumber() {
        String hash = message1.createMessageHash();
        String secondPart = hash.split(":")[1];
        assertEquals("1", secondPart,
                "Second part of hash must be the message number");
    }

    @Test
    public void testMessageHashThirdPartIsFirstAndLastWord() {
        // Message: "Hi Mike, can you join us for dinner tonight?"
        // Expected third part: HITONIGHT
        String hash = message1.createMessageHash();
        String thirdPart = hash.split(":")[2];
        assertEquals("HITONIGHT", thirdPart,
                "Third part must be first word + last word in caps");
    }

    @Test
    public void testMessageHashTestCase1FullFormat() {
        // Full format check: XX:1:HITONIGHT
        String hash = message1.createMessageHash();
        assertTrue(hash.matches("[0-9]{2}:1:HITONIGHT"),
                "Hash format should be 2digits:messageNumber:FIRSTLAST");
    }

    @Test
    public void testMessageHashTestCase2Format() {
        // Message: "Hi Keegan, did you receive the payment?"
        // Expected: XX:2:HIPAYMENT
        String hash = message2.createMessageHash();
        assertTrue(hash.matches("[0-9]{2}:2:HIPAYMENT"),
                "Hash for message 2 should be 2digits:2:HIPAYMENT");
    }

    // -------------------------------------------------------
    // MESSAGE ID TESTS
    // -------------------------------------------------------

    @Test
    public void testCheckMessageIDLength() {
        assertTrue(message1.checkMessageID(),
                "Message ID must be 10 characters or fewer");
    }

    @Test
    public void testMessageIDIsNotNull() {
        assertNotNull(message1.getMessageID());
    }

    @Test
    public void testMessageIDIsTenDigits() {
        String id = message1.getMessageID();
        assertEquals(10, id.length(), "Message ID must be exactly 10 digits");
        assertTrue(id.matches("\\d{10}"), "Message ID must contain only digits");
    }

    // -------------------------------------------------------
    // SENT MESSAGE OPTION TESTS
    // -------------------------------------------------------

    @Test
    public void testSentMessageOptionSend() {
        Message msg = new Message(1, "+271234567", "Hi test message here");
        assertEquals("Message successfully sent.", msg.SentMessage(1));
    }

    @Test
    public void testSentMessageOptionDisregard() {
        Message msg = new Message(1, "+271234567", "Hi test message here");
        assertEquals("Press 0 to delete the message.", msg.SentMessage(2));
    }

    @Test
    public void testSentMessageOptionStore() {
        Message msg = new Message(1, "+271234567", "Hi test message here");
        assertEquals("Message successfully stored.", msg.SentMessage(3));
    }

    // -------------------------------------------------------
    // TOTAL MESSAGES COUNTER TEST
    // -------------------------------------------------------

    @Test
    public void testReturnTotalMessagesIncrementsOnSend() {
        int before = Message.returnTotalMessagess();
        Message msg = new Message(1, "+271234567", "Hi test message here");
        msg.SentMessage(1);
        assertEquals(before + 1, Message.returnTotalMessagess(),
                "Total messages count must increment by 1 after sending");
    }
}
