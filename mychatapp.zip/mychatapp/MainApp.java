cd C:\Users\Student\Desktop\ChatAppPart1; "JAVA_HOME=C:\\Program Files\\Apache NetBeans\\jdk" cmd /c "\"C:\\Program Files\\Apache NetBeans\\java\\maven\\bin\\mvn.cmd\" -Dexec.vmArgs= \"-Dexec.args=${exec.vmArgs} -classpath %classpath ${exec.mainClass} ${exec.appArgs}\" \"-Dexec.executable=C:\\Program Files\\Apache NetBeans\\jdk\\bin\\java.exe\" -Dexec.mainClass=com.mycompany.chatapppart1.MainApp -Dexec.classpathScope=runtime -Dexec.appArgs= \"-Dmaven.ext.class.path=C:\\Program Files\\Apache NetBeans\\java\\maven-nblib\\netbeans-eventspy.jar\" --no-transfer-progress process-classes org.codehaus.mojo:exec-maven-plugin:3.5.1:exec"
WARNING: A terminally deprecated method in sun.misc.Unsafe has been called
WARNING: sun.misc.Unsafe::staticFieldBase has been called by com.google.inject.internal.aop.HiddenClassDefiner (file:/C:/Program%20Files/Apache%20NetBeans/java/maven/lib/guice-5.1.0-classes.jar)
WARNING: Please consider reporting this to the maintainers of class com.google.inject.internal.aop.HiddenClassDefiner
WARNING: sun.misc.Unsafe::staticFieldBase will be removed in a future release
Scanning for projects...

---------------------< com.mycompany:ChatAppPart1 >---------------------
Building ChatAppPart1 1.0-SNAPSHOT
  from pom.xml
--------------------------------[ jar ]---------------------------------

--- resources:3.3.1:resources (default-resources) @ ChatAppPart1 ---
skip non existing resourceDirectory C:\Users\Student\Desktop\ChatAppPart1\src\main\resources

--- compiler:3.13.0:compile (default-compile) @ ChatAppPart1 ---
Recompiling the module because of changed source code.
Compiling 3 source files with javac [debug release 25] to target\classes

--- exec:3.5.1:exec (default-cli) @ ChatAppPart1 ---
Enter first name: Milanathi
Enter last name: Heleni
Enter username: Mila_
Username successfully captured.
Enter password: Milanathi@01
Password successfully captured.
Enter cell phone number (e.g. +27831234567): +27123456789
Cell phone number successfully added.

--- Login ---
Enter username: Mila_
Enter password: Milanathi@01
Welcome Milanathi, Heleni it is great to see you again.

Welcome to QuickChat.
How many messages would you like to send? 1

--- Menu ---
1) Send Messages
2) Show recently sent messages
3) Quit
Choose an option: 1

--- Message 1 of 1 ---
Enter recipient cell number (e.g. +27123456789): +27987654321
Cell phone number successfully captured.
Enter your message (max 250 characters): sho

--- Message Details ---
Message ID:   6245958949
Message Hash: 62:1:SHOSHO
Recipient:    +27987654321
Message:      sho

What would you like to do?
1) Send Message
2) Disregard Message
3) Store Message
Choose: 1
Message successfully sent.

=== Messages Sent This Session ===

--- Sent Message 1 ---
Message ID: 6245958949
Message Hash: 62:1:SHOSHO
Recipient: +27987654321
Message: sho

Total messages sent: 1

--- Menu ---
1) Send Messages
2) Show recently sent messages
3) Quit
Choose an option: 3

Total messages sent: 1
Goodbye!
------------------------------------------------------------------------
BUILD SUCCESS
------------------------------------------------------------------------
Total time:  01:50 min
Finished at: 2026-05-25T14:39:19+02:00
------------------------------------------------------------------------
